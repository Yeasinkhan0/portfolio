# Portfolio – Md. Yeasin Uddin Khan

Personal portfolio website of an AI trainee student learning Machine Learning, Deep Learning and Generative AI.

## Contents
- About, learning path, skills and projects
- Contact details (email, WhatsApp, GitHub)

## Run locally
Open `index.html` in any browser. No build step needed.

## Tech
Plain HTML, CSS and a little JavaScript. Light and dark mode supported, mobile friendly.
